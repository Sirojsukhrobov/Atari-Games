import gym
import numpy as np
import matplotlib.pyplot as plt
from deap import creator
from deap import base, algorithms
from deap import tools
import random
import algelitism
from neuralnetwork import NNetwork
import time


env = gym.make('CartPole-v1')
NEURONS_IN_LAYERS = [4, 1]
network = NNetwork(*NEURONS_IN_LAYERS)
LENGTH_CHROM = NNetwork.getTotalWeights(*NEURONS_IN_LAYERS)
LOW = -1.0
UP = 1.0
ETA = 20
POPULATION_SIZE = 20
P_CROSSOVER = 0.9
P_MUTATION = 0.1
MAX_GENERATIONS = 50
HALL_OF_FAME_SIZE = 2
hof = tools.HallOfFame(HALL_OF_FAME_SIZE)
RANDOM_SEED = 42
random.seed(RANDOM_SEED)
creator.create("FitnessMax", base.Fitness, weights=(1.0,))
creator.create("Individual", list, fitness=creator.FitnessMax)

toolbox = base.Toolbox()
toolbox.register("randomWeight", random.uniform, -1.0, 1.0)
toolbox.register("individualCreator", tools.initRepeat, creator.Individual, toolbox.randomWeight, LENGTH_CHROM)
toolbox.register("populationCreator", tools.initRepeat, list, toolbox.individualCreator)
population = toolbox.populationCreator(n=POPULATION_SIZE)


def getScore(individual):
    network.set_weights(individual)

    observation = env.reset()
    actionCounter = 0
    totalReward = 0

    done = False
    while not done:
        actionCounter += 1
        action = int(network.predict(observation.reshape(1, -1)))
        observation, reward, done, info = env.step(action)
        totalReward += reward

    return totalReward,


toolbox.register("evaluate", getScore)
toolbox.register("select", tools.selTournament, tournsize=2)
toolbox.register("mate", tools.cxSimulatedBinaryBounded, low=LOW, up=UP, eta=ETA)
toolbox.register("mutate", tools.mutPolynomialBounded, low=LOW, up=UP, eta=ETA, indpb=1.0/LENGTH_CHROM)

stats = tools.Statistics(lambda ind: ind.fitness.values)
stats.register("max", np.max)
stats.register("avg", np.mean)

population, logbook = algelitism.eaSimpleElitism(population, toolbox,
                                        cxpb=P_CROSSOVER,
                                        mutpb=P_MUTATION,
                                        ngen=MAX_GENERATIONS,
                                        halloffame=hof,
                                        stats=stats,
                                        verbose=True)

maxFitnessValues, meanFitnessValues = logbook.select("max", "avg")

best = hof.items[0]
print(best)

plt.plot(maxFitnessValues, color='red')
plt.plot(meanFitnessValues, color='green')
plt.xlabel('Generation')
plt.ylabel('Max/average fitness')
plt.title('Dependence of maximum and average fitness on generation')
plt.show()

observation = env.reset()
action = int(network.predict(observation.reshape(1, -1)))

while True:
    env.render()
    observation, reward, done, info = env.step(action)
    if done:
        break
    time.sleep(0.03)
    action = int(network.predict(observation.reshape(1, -1)))
env.close()
